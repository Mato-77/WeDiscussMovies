create function check_constraint(integer) returns character
    language sql
as
$$
select type from project.persons where person_id = $1
$$;

alter function check_constraint(integer) owner to db_202122z_va_prj_wediscussmovies_owner;

